/// <reference path="../../elm.d.ts" />

var app = Elm.Main.init({ node: document.querySelector('main') })
// you can use ports and stuff here